#!/bin/sh

date > dyna_na_mpi.out
mpirun -n 2 ../bin/dyna_na_mpi >> dyna_na_mpi.out
date >> dyna_na_mpi.out
