#include<stdio.h>

main()
{

printf("taille float =%d\n",sizeof(float));
printf("taille double =%d\n",sizeof(double));
}
