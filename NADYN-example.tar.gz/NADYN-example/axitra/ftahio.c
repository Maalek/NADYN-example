/*
 * fortran call able routines to read/write AH data to the XDR format. DON'T
 * FORGET TO DECLARE THE FUNCTIONS AS RETURNING INTEGER VALUE
 * 
 * integer openxdr,stream,rdxdr.., wrxdr..
 * 
 * stream= openxdr   (filename, mode)	!mode='r' or 'w' 
 *    call closexdr  (stream) 
 *    ier= rdxdr     (stream, ahheader, data) 
 *    ier= rdxdrhead (stream, ahheader) 
 *    ier= rdxdrdata (stream, ahheader, data) 
 *    ier= wrxdr     (stream, ahheader, data) 
 *    ier= wrxdrhead (stream, ahheader) 
 *    ier= wrxdrdata (stream, ahheader, data)
 *
 *    call getnullheader (header)
 * 
 * return 0 on success, -1 otherwise
 */

#include <stdio.h>
#include <rpc/rpc.h>
#include "ahhead.h"

typedef struct {
	FILE           *fp;
	XDR             xdrio;
}               AHIO;

char progname[]="convm";

int
#ifdef UNDERSCORE
wrxdr_(ahio, header, data)
#else
wrxdr(ahio, header, data)
#endif
        ahhed          *header;
        char           *data;
        AHIO          **ahio;
{
        if (xdr_putrecord(header, data, &(*ahio)->xdrio) < 0) {
                fprintf(stderr, "wrxdr: error writing record\n");
                return (-1);
        }
        return (0);
}
 
int
#ifdef UNDERSCORE
wrxdrhead_(ahio, header)
#else
wrxdrhead(ahio, header)
#endif
        ahhed          *header;
        AHIO          **ahio;
{
 
        if (xdr_puthead(header, &(*ahio)->xdrio) < 0) {
                fprintf(stderr, "wrxdrhead: error writing header\n");
                return (-1);
        }
        return (0);
}
int
#ifdef UNDERSCORE
wrxdrdata_(ahio, header, data)
#else
wrxdrdata(ahio, header, data)
#endif
        ahhed          *header;
        char           *data;
        AHIO          **ahio;
{
 
        if (xdr_putdata(header, data, &(*ahio)->xdrio) < 0) {
                fprintf(stderr, "wrxdrdata: error writing data\n");
                return (-1);
        }
        return (0);
}

int
#ifdef UNDERSCORE
rdxdr_(ahio, header, data)
#else
rdxdr(ahio, header, data)
#endif
	ahhed          *header;
	char           *data;
	AHIO          **ahio;
{
	if (xdr_getrecord(header, data, &(*ahio)->xdrio) < 0) {
		fprintf(stderr, "rdxdr: error reading record\n");
		return (-1);
	}
	return (0);
}

int
#ifdef UNDERSCORE
rdxdrhead_(ahio, header)
#else
rdxdrhead(ahio, header)
#endif
	ahhed          *header;
	AHIO          **ahio;
{

	if (xdr_gethead(header, &(*ahio)->xdrio) < 0) {
		fprintf(stderr, "rdxdrhead: error reading record\n");
		return (-1);
	}
	return (0);
}
int 
#ifdef UNDERSCORE
rdxdrdata_(ahio, header, data)
#else
rdxdrdata(ahio, header, data)
#endif
	ahhed          *header;
	char           *data;
	AHIO          **ahio;
{

	if (xdr_getdata(header, data, &(*ahio)->xdrio) < 0) {
		fprintf(stderr, "rdxdrdata: error reading record\n");
		return (-1);
	}
	return (0);
}

AHIO           *
#ifdef UNDERSCORE
openxdr_(filename, mode, len)
#else
openxdr(filename, mode, len)
#endif
	char           *filename, *mode;
	int            *len;
{
	enum xdr_op     type;
	char            Cfilename[100],iomode[2];
	AHIO		*ahio;
	FILE		*fp;

	end_string_by_0(filename, Cfilename, len);
	end_string_by_0(mode, iomode, 2);


	if ((fp = fopen(Cfilename, iomode)) == (FILE *) 0) {
		fprintf(stderr, "openxdr: cannot open file %s\n", Cfilename);
		return ((AHIO *) 0);
	}
        ahio = (AHIO *) malloc (sizeof(AHIO));
	ahio->fp=fp;
	switch (*mode) {
	case 'r':
		type = XDR_DECODE;
		break;
	case 'w':
		type = XDR_ENCODE;
		break;
	default:
		return ((AHIO *) 0);
	}
	xdrstdio_create(&ahio->xdrio, ahio->fp, type);
	return (ahio);
}

void 
#ifdef UNDERSCORE
closexdr_(ahio)
#else
closexdr(ahio)
#endif
	AHIO          **ahio;
{
	fclose((*ahio)->fp);
	xdr_destroy(&(*ahio)->xdrio);
        free(ahio);
}
/******************************************************************************
 END_STRING_BY_0: termine une chaine de caractere fortran par le caractere null
*******************************************************************************/

end_string_by_0(stringin, stringout, len)
	char           *stringin, *stringout;
	int             len;
{
	register int    i = 0;
	while ((stringin[i] != 32) && (stringin[i] != 0) && (i < len)) {
		stringout[i] = stringin[i];
		i++;
	}
	stringout[i] = 0;
}

void
#ifdef UNDERSCORE
getnullheader_(header)
#else
getnullheader (header)
#endif
ahhed	*header;
{
get_null_head(header);
}
